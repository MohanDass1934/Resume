package com.DBconnection;
import java.sql.*;
public class DBconnection {


	public static Connection getConnection () {
		Connection con=null;
		String url="jdbc:mysql://localhost:3306/student?characterEncoding=UTF-8";
		String name="root";
		String password="mohan";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,name,password);
		}catch(Exception ex) {
			System.out.println(ex);
		}
		return con;
	}
}
