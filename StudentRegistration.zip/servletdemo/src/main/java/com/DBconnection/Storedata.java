package com.DBconnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.enter.Storevalue;

public class Storedata {

	public static int save(Storevalue values) {
		int status = 0;
		try {
			Connection con = DBconnection.getConnection();
			long number = values.getNumber();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from studentdetails where number= '"+number+"'");
			if (rs.next()) {
				status=0;
			} else {
				try {
					PreparedStatement st1 = con.prepareStatement("insert into studentdetails"
							+ "(name,number,age,roomnumber,fees,adharnumber,adderss) value(?,?,?,?,?,?,?) ");
					st1.setString(1, values.getName());
					st1.setLong(2, values.getNumber());
					st1.setInt(3, values.getAge());
					st1.setString(4, values.getRoomnumber());
					st1.setInt(5, values.getFees());
					st1.setString(6, values.getAdharcard());
					st1.setString(7, values.getAdderss());
					status = st1.executeUpdate();
				}catch(Exception ex){
					System.out.println(ex);
				}
			}
			con.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return status;

	}

	public static int delete(int rollnum){
		int status=0;
		try{
			Connection con=DBconnection.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from studentdetails where idstd=?");
			ps.setInt(1,rollnum);
			status=ps.executeUpdate();
			if(status>0) {
				PreparedStatement prs=con.prepareStatement("update studentdetails set idstd=idstd-1 where idstd>?");
				prs.setInt(1, rollnum);
				prs.executeUpdate();
				con.close();
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}

	
	
	
	public static List<Storevalue> getAllRecords() {
		List<Storevalue> list = new ArrayList<Storevalue>();
		try {
			Connection con = DBconnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from studentdetails");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Storevalue bean = new Storevalue();
				bean.setRollnum(rs.getInt(1));
				bean.setName(rs.getString(2));
				bean.setNumber(rs.getLong(3));
				bean.setAge(rs.getInt(4));
				bean.setAdharcard(rs.getString(5));
				bean.setFees(rs.getInt(6));
				bean.setRoomnumber(rs.getString(7));
				bean.setAdderss(rs.getString(8));
				list.add(bean);
			}
			con.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}

		return list;
	}
	
	
	// update the content in the database into edit and 
	public static int update(Storevalue st) {
		
		int status =0;
		try {
			Connection con = DBconnection.getConnection();
			String sql ="update studentdetails set name=?,number=?,age=?,adharnumber=?,fees=?,roomnumber=?,adderss=? where idstd=?";
			PreparedStatement stm = con.prepareStatement(sql);
			stm.setString(1, st.getName());
			stm.setLong(2, st.getNumber());
			stm.setInt(3, st.getAge());
			stm.setString(4, st.getAdharcard());;
			stm.setInt(5, st.getFees());
			stm.setString(6, st.getRoomnumber());
			stm.setString(7, st.getAdderss());
			stm.setInt(8, st.getRollnum());
			status= stm.executeUpdate();
			con.close();
		}catch(Exception ex) {
			System.out.println(ex);
		}
		
		return status;
	}

	public static Storevalue getRecordByrollnum(int rollnum) {
		
		Storevalue st=new Storevalue();
		try{
			Connection con=DBconnection.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from studentdetails where idstd=?");
			ps.setInt(1,rollnum);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				st.setRollnum(rs.getInt(1));
				st.setName(rs.getString(2));
				st.setNumber(rs.getLong(3));
				st.setAge(rs.getInt(4));
				st.setAdharcard(rs.getString(5));
				st.setFees(rs.getInt(6));         
				st.setRoomnumber(rs.getString(7));
				st.setAdderss(rs.getString(8));
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		
		return st;
	}
	
	
	
	
}
