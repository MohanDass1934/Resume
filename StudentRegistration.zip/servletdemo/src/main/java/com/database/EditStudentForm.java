package com.database;

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

import com.DBconnection.Storedata;
import com.enter.*;
/**
 * Servlet implementation class EditStudentForm
 */
public class EditStudentForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		// get tha roll number and send ths rollnumber int o the another file
		int rollnum= Integer.parseInt( request.getParameter("rollnum"));
		
		//Create the class and get the all data
		Storevalue st=Storedata.getRecordByrollnum(rollnum);
	
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Edit Student Form</title>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("navbar.html").include(request, response);
		out.println("<div class='editcontainer'>");
		
		out.println("<h1>Edit Student Form</h1>");
		out.println("<form action='EditStudent' method='post'>");
		out.println("<table>");
		out.println("<input type='hidden'name='rollnum' value='"+st.getRollnum()+"'/>");
		out.println("<tr><td><b>Name:</b></td><td><input type='text'style='border:none; background-color: transparent ;'name='name' value='"+st.getName()+"'/></td></tr>");
		out.println("<tr><td><b>Number:</b></td><td><input type='number'style='border:none;background-color: transparent ;'name='number' value='"+st.getNumber()+"'/></td></tr>");
		out.println("<tr><td><b>Age:</b></td><td><input type='number'style='border:none;background-color: transparent ;'name='age' value='"+st.getAge()+"'/></td></tr>");
		out.println("<tr><td><b>RoomNumber:</b></td><td><input type='text' style='border:none;background-color: transparent ;'name='room' value='"+st.getRoomnumber()+"'/></td></tr>");
		out.println("<tr><td><b>Fee:</b></td><td><input type='number'style='border:none;background-color: transparent ;'name='fees' value='"+st.getFees()+"'/></td></tr>");
		out.println("<tr><td><b>Adharcard Number:</b></td><td><input type='text'  style='border:none;background-color: transparent ;' name='aadhaar' value='"+st.getAdharcard()+"'/></td></tr>");
		out.println("<tr><td><b>Address:</b></td><td><textarea style='border:none;background-color: transparent ;'name='address' style='width:300px;height:100px;'>"+st.getAdderss()+"</textarea></td></tr>");
		out.println("<tr><td colspan='2' align='center'><input type='submit' value='Update Student'/></td></tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		request.getRequestDispatcher("footer.html").include(request, response);
		out.println("</body>");
		out.println("</html>");
				
		out.close();
		
		
		
	
	}

	

}
