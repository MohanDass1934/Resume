package com.database;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.DBconnection.Storedata;
import com.enter.Storevalue;

/**
 * Servlet implementation class Showdetails
 */
public class Showdetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		    out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>View Student</title>");
			out.println("<link rel='stylesheet' href='style.css'/>");
			out.println("</head>");
			out.println("<body>");
			request.getRequestDispatcher("navbar.html").include(request, response);
			out.println("<div class='containers'>");
		    List<Storevalue> list=Storedata.getAllRecords();
			out.println("<table class='table table-bordered table-striped'>");
			out.print("<thead><tr><th>Rollno</th>"
					+ "<th>Name</th>"
					+ "<th>Number</th>"
					+ "<th>Age</th>"
					+ "<th>RoomNumber</th>"
					+ "<th>Fees</th>"
					+ "<th>AdharNumber</th>"
					+ "<th>Address</th>"
					+ "<th>Edit</th>"
					+ "<th>Delete</th></tr></thead>");
			for(Storevalue bean:list){
				out.print("<tbody><tr><td>"+bean.getRollnum()+"</td><td>"+bean.getName()
				+"</td><td>"+bean.getNumber()+"</td><td>"+bean.getAge()
				+"</td><td>"+bean.getRoomnumber()+"</td><td>"+bean.getFees()
				+"</td><td>"+bean.getAdharcard()+"</td><td>"+bean.getAdderss()
				+"</td><td><a href='EditStudentForm?rollnum="+bean.getRollnum()
				+"'>Edit</a></td><td><a href='DeleteStudent?rollnum="+bean.getRollnum()
				+"'>Delete</a></td></tr><tbody>");
			}
			out.println("</table>");
			out.println("</div>");
			request.getRequestDispatcher("footer.html").include(request, response);
			out.println("</body>");
			out.println("</html>");
			out.close();
	
			
	}

	

}
