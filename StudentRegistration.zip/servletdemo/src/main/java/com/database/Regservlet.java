package com.database;
import java.sql.*;
import java.util.List;

import com.DBconnection.Storedata;
import com.enter.Storevalue;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;

/**
 * Servlet implementation class Regservlet
 */
public class Regservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		    response.setContentType("text/html");
		    
	        // Get a writer to send the response back to the client
	        PrintWriter out = response.getWriter();
	        
	        String name = request.getParameter("name");
	        
	        
	        long number=Long.parseLong(request.getParameter("number"));
	        int age = Integer.parseInt(request.getParameter("age"));
	        String room = request.getParameter("room");
	        int fees = Integer.parseInt(request.getParameter("fees"));
	        String address = request.getParameter("address");
	        String aadhaar = request.getParameter("aadhaar");
	       
	         
	        
	     Storevalue values = new Storevalue(name,number,age,room,fees,address,aadhaar);
	     
	     int status = Storedata.save(values);
	     
	    

	        // Generate the HTML response
	        out.println("<html>");
	        out.println("<head>");
	        out.println("<title>InsertionData</title>");
	        out.println("<link rel='stylesheet' href='style.css'/>");
	        out.println("</head>");
	        out.println("<body style='font-family: Arial, sans-serif;'>");
	        if(status>0){
	        	out.println("<script>alert('Inserted Successfully! :::: ');</script>");
	        	request.getRequestDispatcher("index.jsp").include(request, response);
	        }
	        else {
	        	out.println("<script>alert('The data is already inserted! ::::');</script>");
	        	request.getRequestDispatcher("Showdetails").include(request, response);
	        }
			
	        out.println("</body>");
	        out.println("</html>");
	        
	      
	}
	

}
