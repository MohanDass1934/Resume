package com.database;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.DBconnection.*;

/**
 * Servlet implementation class DeleteStudent
 */
public class DeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String srollno=request.getParameter("rollnum");
		int rollno=Integer.parseInt(srollno);
		int status =Storedata.delete(rollno);
		
		if(status>0) 
			response.sendRedirect("Showdetails");
		else
			response.sendRedirect("Error.html");
		
	}

	
}
