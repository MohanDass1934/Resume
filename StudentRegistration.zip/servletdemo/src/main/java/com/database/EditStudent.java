package com.database;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import com.DBconnection.Storedata;
import com.enter.*;
/**
 * Servlet implementation class EditStudent
 */
public class EditStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int rollnum=Integer.parseInt(request.getParameter("rollnum"));
		String name=request.getParameter("name");
	 	long number=Long.parseLong(request.getParameter("number"));
	    int age=Integer.parseInt(request.getParameter("age"));
		String room=request.getParameter("room");
		int fees=Integer.parseInt(request.getParameter("fees"));
		String aadhaar=request.getParameter("aadhaar");
		String address=request.getParameter("address");
		
		Storevalue values =new Storevalue(rollnum,name,number,age,room,fees,aadhaar,address);
		
		int status=Storedata.update(values);
		
		if(status>0) {
			response.sendRedirect("Showdetails");
			
		}else {
			response.sendRedirect("Error.html");
		}
		out.close();
	}

}
