package com.enter;

import java.math.BigInteger;

public class Storevalue {

	 private String name, adharcard, adderss, roomnumber ;
	 private long number;
	 private int rollnum, age,fees;
	
	
	 // Addd with roll number.........  in constructor methods
	public Storevalue(int rollnum,String name,long number, int age,String roomnumber, int fees, String adharcard, String adderss ) {
		super();
		this.name = name;
		this.adharcard = adharcard;
		this.adderss = adderss;
		this.roomnumber = roomnumber;
		this.number = number;
		this.rollnum = rollnum;
		this.age = age;
		this.fees = fees;
	}

    // without rollnumber ... constructor method ....................
	public Storevalue(String name, long number, int age, 
			String roomnumber, int fees, String address,
			String aadhaar) {
		super();
		this.name = name;
		this.number = number;
		this.age = age;
		this.roomnumber = roomnumber;
		this.fees = fees;
		this.adderss = address;
		this.adharcard = aadhaar;
	}
	
	public Storevalue() {}

	public  String getName() {
		return name;
	}
	public  void setName(String name) {
		this.name = name;
	}
	public String getAdharcard() {
		return adharcard;
	}
	public  void setAdharcard(String adharcard) {
		this.adharcard = adharcard;
	}
	public String getAdderss() {
		return adderss;
	}
	public void setAdderss(String adderss) {
		this.adderss = adderss;
	}
	public  String getRoomnumber() {
		return roomnumber;
	}
	public void setRoomnumber(String roomnumber) {
	 this.roomnumber = roomnumber;
	}
	public  long getNumber() {
		return number;
	}
	public  void setNumber(long number) {
		this.number = number;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public  int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public int getRollnum() {
		return rollnum;
	}
	public void setRollnum(int rollnum) {
		this.rollnum = rollnum;
	}
	
	
}
